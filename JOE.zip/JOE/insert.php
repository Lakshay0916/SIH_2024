<?php
// Database connection parameters
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = "00000000"; // Change this to your MySQL password
$dbname = "doc"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch form data
$fullName = $_POST['fullName'];
$dob = $_POST['dob'];
$age = $_POST['age'];
$gender = $_POST['gender'];
$bloodGroup = $_POST['bloodGroup'];
$emergencyContactName = $_POST['emergencyContactName'];
$emergencyContactNumber = $_POST['emergencyContactNumber'];
$doctorName = $_POST['doctorName'];
$doctorContact = $_POST['doctorContact'];
$allergies = $_POST['allergies'];
$medicalConditions = $_POST['medicalConditions'];
$medications = $_POST['medications'];

// Prepare and execute SQL statement to insert data into the database
$sql = "INSERT INTO patient_records (full_name, dob, age, gender, blood_group, emergency_contact_name, emergency_contact_number, doctor_name, doctor_contact, allergies, medical_conditions, medications)
VALUES ('$fullName', '$dob', '$age', '$gender', '$bloodGroup', '$emergencyContactName', '$emergencyContactNumber', '$doctorName', '$doctorContact', '$allergies', '$medicalConditions', '$medications')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
