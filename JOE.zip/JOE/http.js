import express from "express";
import pg from "pg";
import fs from "fs";
import qr from "qr-image";
import path from "path";

const __dirname=path.resolve();
var id;
function createImage(URL){
    var qr_svg=qr.image(URL);
    qr_svg.pipe(fs.createWriteStream("./public/qr.png"));
}

const port =3000;
const app =express();
const db=new pg.Client({
    user: "postgres",
    host:"localhost",
    database:"postgres",
    port:"5432",
    password:"000000"
});
db.connect();

app.use(express.urlencoded({extended:"true"}));
app.use(express.static("public"));

app.get(
    "/",(req,res)=>{
        return res.render("lol.ejs");
    }
);

app.post(
    "/submit",async (req,res)=>{

        const name=req.body.fullName;
        const dob =req.body.dob;
        const age= req.body.age;
        const gen=req.body.gender;
        const bg=req.body.bloodGroup;
        const emerContact=req.body.emergencyContactName;
        const emerNum=req.body.emergencyContactNumber;
        const docName=req.body.doctorName;
        const docContact=req.body.dooctorContact;
        const aller=req.body.allergies;
        const medicalInfo=req.body.medicalConditions;
        const med=req.body.medications;
        
        try{
        const totalDetails=await db.query("SELECT * FROM data");
        id=(totalDetails.rows.length);
        
        await db.query(
            "INSERT INTO data (name, id, DOB, age, gender, bloodGroup, emerContactName, emerContactNum, docName, docContact, allergies, medicalCondition, currentMedications) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)",
            [name, id, dob, age, gen, bg, emerContact, emerNum, docName, docContact, aller, medicalInfo, med]
        );
    }catch(err){
        console.log(err);
    }
        
// `       const abc= await db.query("INSERT INTO data (name,id,DOB,age,gender,bloodGroup,emerContactName,emerContactNum,docName,docContact,allergies,medicalCondition,cureentMedications) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)",[name,id,dob,age,gen,bg,emerContact,emerNum,docName,docContact,aller,medicalInfo,med]);


        res.redirect("/success");


    });

app.get(
    "/success",(req,res)=>{
        const URL=id;
        createImage(id);
        res.render("page2.ejs");
    }
)
app.listen(port,(err)=>{
    if(err){
        console.log(err);
    }
    else{
        console.log("Server running on port",port);
    }
}
);
